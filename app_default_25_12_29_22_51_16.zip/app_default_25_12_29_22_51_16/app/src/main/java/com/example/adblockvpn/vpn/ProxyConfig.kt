package com.example.adblockvpn.vpn

data class ProxyConfig(
    val enabled: Boolean = false,
    val host: String = "",
    val port: Int = 8080,
    val type: ProxyType = ProxyType.HTTP
)

enum class ProxyType {
    HTTP, SOCKS5
}
