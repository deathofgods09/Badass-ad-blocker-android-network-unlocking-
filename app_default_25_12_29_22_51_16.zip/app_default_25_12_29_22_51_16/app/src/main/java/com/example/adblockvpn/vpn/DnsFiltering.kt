package com.example.adblockvpn.vpn

import android.util.Log

class DnsFiltering {
    // Simple blocklist of known ad/tracking domains
    private val blocklist = setOf(
        "doubleclick.net",
        "googleads.g.doubleclick.net",
        "adservice.google.com",
        "ads.youtube.com",
        "analytics.google.com",
        "facebook.com/tr",
        "ads.tiktok.com",
        "adserver.com"
    )

    /**
     * Checks if a hostname should be blocked.
     * In a production app, this would use a Bloom Filter or a high-performance Trie.
     */
    fun isBlocked(hostname: String): Boolean {
        val result = blocklist.any { domain -> hostname.contains(domain, ignoreCase = true) }
        if (result) {
            Log.d("DnsFiltering", "Blocked access to: $hostname")
        }
        return result
    }

    /**
     * Returns the null IP for blocked domains.
     */
    fun getBlockedAddress(): String = "0.0.0.0"
}
