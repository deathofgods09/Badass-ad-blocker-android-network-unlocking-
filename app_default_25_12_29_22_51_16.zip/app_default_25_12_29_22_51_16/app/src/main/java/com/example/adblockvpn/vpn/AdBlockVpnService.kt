package com.example.adblockvpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.IOException
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean

class AdBlockVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val isRunning = AtomicBoolean(false)
    
    companion object {
        const val ACTION_CONNECT = "com.example.adblockvpn.START"
        const val ACTION_DISCONNECT = "com.example.adblockvpn.STOP"
        private const val CHANNEL_ID = "vpn_channel"
        private const val NOTIFICATION_ID = 1
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            stopVpn()
            return START_NOT_STICKY
        }
        
        setupForeground()
        startVpn()
        return START_STICKY
    }

    private fun setupForeground() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "VPN Service",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)

        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Shield VPN is Active")
            .setContentText("Blocking ads and securing your connection")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun startVpn() {
        if (isRunning.get()) return
        isRunning.set(true)

        try {
            val builder = Builder()
                .setSession("ShieldVPN")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                // Use a secure DNS provider or local interception
                .addDnsServer("1.1.1.1") 
                .addDnsServer("8.8.8.8")
                .setMtu(1500)

            // Implement network unlocking via Proxy configuration if provided
            // This tells the system to route traffic through the TUN interface
            vpnInterface = builder.establish()
            
            Log.i("VPN", "VPN Interface established")
            
            // In a real implementation, we would start a thread to read/write 
            // from vpnInterface.fileDescriptor to filter DNS packets.
            // For this version, we configure the system routes.
            
        } catch (e: Exception) {
            Log.e("VPN", "Failed to start VPN", e)
            stopSelf()
        }
    }

    private fun stopVpn() {
        isRunning.set(false)
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: IOException) {
            Log.e("VPN", "Error closing interface", e)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
